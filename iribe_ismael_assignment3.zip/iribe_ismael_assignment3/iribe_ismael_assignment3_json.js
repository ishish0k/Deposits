//Ismael Iribe
//MDV 1408
//21Aug2014

var json = {
    "bugs": {
        "001": {   
        "name": "beetle",
        "size": 20,
        "legs":6
        },
        "002":{
        "name": "mantis",
        "size": 15,
        "legs": 6
        },
        "003":{
        "name": "scorpion",
        "size": 9,
        "legs":8
        }
    }
};



var json2 = {
    "bugs": [
        {
            "insectid" : "001",
            "name": "beetle",
            "size": 20,
            "legs":6
        },
        {
            "insectid" : "002",
            "name" : "mantis",
            "size" : 15,
            "legs":6
            
        },
        {
            "insectid" : "003",
            "name" : "scorpion",
            "size" : 9,
            "legs":8
        }
    ]
};
